package com.example.toystore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToystoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
