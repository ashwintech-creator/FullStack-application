package com.toystore.config;

public class JwtConstant {
   public static String SECRET_KEY="budlbnsekjfpoaejfvshjkbdf sdkufhnsufgbjksdfhikln";
   public static String JWT_HEADER="Authorization";
}
