package com.toystore.exception;

// import com.store.model.User;

public class UserException extends Exception{
   public UserException(String message){
    super(message);
   }
}
